ALTER TABLE services 
ADD COLUMN materials_description TEXT;
