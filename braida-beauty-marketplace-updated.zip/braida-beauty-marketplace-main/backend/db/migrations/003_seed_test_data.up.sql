-- Seed test freelancers and services
-- Note: These user IDs will be replaced with actual Clerk IDs in production

-- Test freelancers
INSERT INTO users (id, first_name, last_name, email, role, is_verified, created_at) VALUES
  ('test_freelancer_1', 'Amara', 'Okafor', 'amara.okafor@test.com', 'FREELANCER', true, NOW()),
  ('test_freelancer_2', 'Zainab', 'Hassan', 'zainab.hassan@test.com', 'FREELANCER', true, NOW()),
  ('test_freelancer_3', 'Keisha', 'Williams', 'keisha.williams@test.com', 'FREELANCER', true, NOW()),
  ('test_freelancer_4', 'Nia', 'Campbell', 'nia.campbell@test.com', 'FREELANCER', true, NOW()),
  ('test_freelancer_5', 'Chiamaka', 'Nwosu', 'chiamaka.nwosu@test.com', 'FREELANCER', true, NOW()),
  ('test_freelancer_6', 'Tasha', 'Brown', 'tasha.brown@test.com', 'FREELANCER', true, NOW()),
  ('test_freelancer_7', 'Folake', 'Adeyemi', 'folake.adeyemi@test.com', 'FREELANCER', true, NOW()),
  ('test_freelancer_8', 'Maya', 'Thompson', 'maya.thompson@test.com', 'FREELANCER', true, NOW()),
  ('test_freelancer_9', 'Chioma', 'Obi', 'chioma.obi@test.com', 'FREELANCER', true, NOW()),
  ('test_freelancer_10', 'Jasmine', 'Davis', 'jasmine.davis@test.com', 'FREELANCER', true, NOW());

-- Freelancer profiles
INSERT INTO freelancer_profiles (user_id, display_name, bio, location_area, postcode, travel_radius_miles, categories, verification_status) VALUES
  ('test_freelancer_1', 'Amara Braids', 'Specializing in protective styles with 8+ years experience. Natural hair expert.', 'South London', 'SW9 8DN', 10, '["hair"]', 'verified'),
  ('test_freelancer_2', 'Zainab Beauty Studio', 'Certified makeup artist specializing in bridal and special occasion looks.', 'East London', 'E15 2GW', 8, '["makeup"]', 'verified'),
  ('test_freelancer_3', 'Keisha Hair Lounge', 'Creative braider and loc specialist. Book your transformation today!', 'North London', 'N15 4QL', 12, '["hair"]', 'verified'),
  ('test_freelancer_4', 'Nia Glam', 'Professional MUA for all skin tones. Bridal specialist with portfolio.', 'West London', 'W10 5NE', 15, '["makeup"]', 'verified'),
  ('test_freelancer_5', 'Chi Couture', 'Expert tailor for aso-ebi and traditional African wear. Custom designs available.', 'Central London', 'SE1 7PB', 5, '["tailoring"]', 'verified'),
  ('test_freelancer_6', 'Tasha Styles', 'Braiding specialist with a passion for intricate cornrow designs.', 'South London', 'SE15 5EW', 10, '["hair"]', 'verified'),
  ('test_freelancer_7', 'Folake Gele & Beauty', 'Traditional gele tying and makeup for Nigerian weddings and events.', 'East London', 'E6 1HX', 20, '["gele", "makeup"]', 'verified'),
  ('test_freelancer_8', 'Maya Hair Studio', 'Natural hair care specialist. Wash, condition, and protective styling.', 'North London', 'N17 0AP', 10, '["hair"]', 'verified'),
  ('test_freelancer_9', 'Chi Chi Tailoring', 'Bespoke tailoring and alterations. Aso-ebi expert with quick turnaround.', 'West London', 'W12 7RJ', 8, '["tailoring"]', 'verified'),
  ('test_freelancer_10', 'Jazz Beauty Bar', 'Glam makeup artist and wig installation specialist.', 'South London', 'SW16 1BW', 12, '["makeup", "hair"]', 'verified');

-- Sample services
INSERT INTO services (freelancer_id, title, category, subcategory, description, base_price_pence, duration_minutes, materials_policy, location_types, travel_fee_pence) VALUES
  ('test_freelancer_1', 'Knotless Box Braids - Medium', 'hair', 'braids', 'Beautiful knotless box braids, medium size. Includes hair.', 15000, 360, 'freelancer_provides', '["freelancer_travels_to_client"]', 1500),
  ('test_freelancer_1', 'Cornrows - Full Head', 'hair', 'braids', 'Classic cornrows in any pattern you desire.', 6000, 180, 'client_provides', '["freelancer_travels_to_client"]', 1000),
  ('test_freelancer_2', 'Bridal Makeup Package', 'makeup', 'bridal', 'Full bridal makeup with trial session included.', 25000, 120, 'freelancer_provides', '["freelancer_travels_to_client"]', 2000),
  ('test_freelancer_2', 'Soft Glam Makeup', 'makeup', 'everyday', 'Natural glam perfect for photos or special occasions.', 8000, 60, 'freelancer_provides', '["freelancer_travels_to_client", "client_travels_to_freelancer"]', 1500),
  ('test_freelancer_3', 'Loc Retwist & Style', 'hair', 'locs', 'Professional loc maintenance and styling.', 7500, 150, 'client_provides', '["client_travels_to_freelancer"]', 0),
  ('test_freelancer_4', 'Bridal Glam', 'makeup', 'bridal', 'Stunning bridal makeup for your big day.', 22000, 90, 'freelancer_provides', '["freelancer_travels_to_client"]', 2500),
  ('test_freelancer_5', 'Aso-Ebi Complete Outfit', 'tailoring', 'traditional', 'Custom-made traditional Nigerian outfit from your fabric.', 35000, 0, 'client_provides', '["client_travels_to_freelancer"]', 0),
  ('test_freelancer_6', 'Jumbo Box Braids', 'hair', 'braids', 'Thick, chunky box braids for a bold look.', 12000, 240, 'freelancer_provides', '["freelancer_travels_to_client"]', 1000),
  ('test_freelancer_7', 'Bridal Gele Tying', 'gele', 'bridal', 'Elaborate bridal gele styling for your wedding.', 15000, 60, 'client_provides', '["freelancer_travels_to_client"]', 2000),
  ('test_freelancer_8', 'Natural Hair Wash & Set', 'hair', 'natural', 'Deep cleanse, condition, and styling for natural hair.', 5500, 120, 'freelancer_provides', '["client_travels_to_freelancer"]', 0),
  ('test_freelancer_9', 'Garment Alterations', 'tailoring', 'alterations', 'Professional alterations for any garment.', 3000, 0, 'client_provides', '["client_travels_to_freelancer"]', 0),
  ('test_freelancer_10', 'Wig Install - Full Lace', 'hair', 'wig', 'Professional wig installation with customization.', 18000, 180, 'both', '["client_travels_to_freelancer"]', 0);

-- Link some services to styles
INSERT INTO service_styles (service_id, style_id) VALUES
  (1, 1), -- Knotless box braids
  (2, 3), -- Cornrows
  (3, 6), -- Bridal glam makeup
  (4, 5), -- Soft glam makeup
  (5, 11), -- Loc retwist
  (6, 6), -- Bridal glam
  (7, 9), -- Aso-ebi tailoring
  (8, 2), -- Box braids
  (9, 7), -- Bridal gele
  (10, 12), -- Natural hair wash & set
  (11, 10), -- Alterations
  (12, 4); -- Wig install
