import { APIError } from "encore.dev/api";
import db from "../db";

interface RateLimitConfig {
  windowMs: number;
  maxRequests: number;
}

const rateLimitConfigs: Record<string, RateLimitConfig> = {
  auth_login: { windowMs: 15 * 60 * 1000, maxRequests: 5 },
  auth_register: { windowMs: 60 * 60 * 1000, maxRequests: 3 },
  auth_forgot_password: { windowMs: 60 * 60 * 1000, maxRequests: 3 },
  auth_reset_password: { windowMs: 60 * 60 * 1000, maxRequests: 5 },
  auth_verify: { windowMs: 60 * 60 * 1000, maxRequests: 10 },
};

export async function checkRateLimit(identifier: string, action: string): Promise<void> {
  const config = rateLimitConfigs[action];
  if (!config) {
    return;
  }

  const windowStart = new Date(Date.now() - config.windowMs);
  const key = `${action}:${identifier}`;

  const count = await db.queryRow<{ count: number }>`
    SELECT COUNT(*) as count
    FROM rate_limit_events
    WHERE key = ${key} AND created_at > ${windowStart}
  `;

  if (count && count.count >= config.maxRequests) {
    throw APIError.resourceExhausted(
      `Too many requests. Please try again later.`
    );
  }

  await db.exec`
    INSERT INTO rate_limit_events (key, created_at)
    VALUES (${key}, NOW())
  `;

  await db.exec`
    DELETE FROM rate_limit_events
    WHERE created_at < ${windowStart}
  `;
}
