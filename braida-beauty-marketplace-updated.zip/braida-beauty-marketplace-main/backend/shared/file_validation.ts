import { APIError } from "encore.dev/api";

export interface FileValidationOptions {
  maxSizeBytes?: number;
  allowedMimeTypes?: string[];
}

const DEFAULT_MAX_SIZE = 10 * 1024 * 1024;
const IMAGE_MIME_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
const DOCUMENT_MIME_TYPES = ["application/pdf", ...IMAGE_MIME_TYPES];

export function validateFileUpload(
  base64Data: string,
  contentType: string,
  options: FileValidationOptions = {}
): Buffer {
  const maxSize = options.maxSizeBytes || DEFAULT_MAX_SIZE;
  const allowedTypes = options.allowedMimeTypes || IMAGE_MIME_TYPES;

  if (!allowedTypes.includes(contentType)) {
    throw APIError.invalidArgument(
      `Invalid file type. Allowed types: ${allowedTypes.join(", ")}`
    );
  }

  const buffer = Buffer.from(base64Data, "base64");

  if (buffer.length > maxSize) {
    const maxMB = (maxSize / (1024 * 1024)).toFixed(1);
    throw APIError.invalidArgument(`File size exceeds ${maxMB}MB limit`);
  }

  if (buffer.length === 0) {
    throw APIError.invalidArgument("File data is empty");
  }

  return buffer;
}

export function extractMimeTypeFromDataUrl(dataUrl: string): string {
  const match = dataUrl.match(/^data:([^;]+);base64,/);
  if (!match) {
    throw APIError.invalidArgument("Invalid data URL format");
  }
  return match[1];
}

export const PRESETS = {
  IMAGE_5MB: { maxSizeBytes: 5 * 1024 * 1024, allowedMimeTypes: IMAGE_MIME_TYPES },
  IMAGE_10MB: { maxSizeBytes: 10 * 1024 * 1024, allowedMimeTypes: IMAGE_MIME_TYPES },
  DOCUMENT_5MB: { maxSizeBytes: 5 * 1024 * 1024, allowedMimeTypes: DOCUMENT_MIME_TYPES },
  DOCUMENT_10MB: { maxSizeBytes: 10 * 1024 * 1024, allowedMimeTypes: DOCUMENT_MIME_TYPES },
};
