import { api } from "encore.dev/api";
import db from "../db";

interface Style {
  id: number;
  name: string;
  description: string | null;
  referenceImageUrl: string | null;
  isActive: boolean;
}

interface ListStylesResponse {
  styles: Style[];
}

// Lists all active styles in the catalog
export const list = api<void, ListStylesResponse>(
  { expose: true, method: "GET", path: "/styles" },
  async (): Promise<ListStylesResponse> => {
    const rows = await db.queryAll<{
      id: number;
      name: string;
      description: string | null;
      reference_image_url: string | null;
      is_active: boolean;
    }>`
      SELECT id, name, description, reference_image_url, is_active
      FROM styles
      WHERE is_active = true
      ORDER BY name ASC
    `;

    const styles = rows.map(row => ({
      id: row.id,
      name: row.name,
      description: row.description,
      referenceImageUrl: row.reference_image_url,
      isActive: row.is_active,
    }));

    return { styles };
  }
);
