import { api } from "encore.dev/api";
import { getAuthData } from "~encore/auth";
import db from "../db";
import { APIError } from "encore.dev/api";
import { Dispute } from "./types";

export interface ListDisputesByBookingRequest {
  booking_id: string;
}

export interface ListDisputesByBookingResponse {
  disputes: Dispute[];
}

export const listByBooking = api(
  { method: "GET", path: "/bookings/:booking_id/disputes", auth: true, expose: true },
  async (req: ListDisputesByBookingRequest): Promise<ListDisputesByBookingResponse> => {
    const auth = getAuthData()!;

    // Fetch the booking participants using template literal syntax for improved
    // type safety and to avoid mixing string interpolation with positional
    // parameters. db.queryRow returns a single row (or undefined) and accepts
    // tagged template literals where parameters are automatically escaped.
    const booking = await db.queryRow<{ client_id: string; freelancer_id: string }>`
      SELECT client_id, freelancer_id
      FROM bookings
      WHERE id = ${req.booking_id}
    `;

    if (!booking) {
      throw APIError.notFound("Booking not found");
    }

    if (auth.userID !== booking.client_id && auth.userID !== booking.freelancer_id) {
      throw APIError.permissionDenied("Access denied");
    }

    // Retrieve all disputes for the booking as an array.  queryAll returns
    // a Promise of an array rather than an AsyncGenerator, simplifying
    // iteration and enabling proper typing.  Using a tagged template
    // literal ensures the booking_id is safely interpolated.
    const disputes = await db.queryAll<Dispute>`
      SELECT *
      FROM disputes
      WHERE booking_id = ${req.booking_id}
      ORDER BY created_at DESC
    `;

    return { disputes };
  }
);
