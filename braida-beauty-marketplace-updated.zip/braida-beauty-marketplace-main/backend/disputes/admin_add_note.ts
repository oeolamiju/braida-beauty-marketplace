import { api } from "encore.dev/api";
import { getAuthData } from "~encore/auth";
import db from "../db";
import { APIError } from "encore.dev/api";

export interface AdminAddNoteRequest {
  dispute_id: string;
  note: string;
}

export interface AdminAddNoteResponse {
  note_id: string;
}

export const adminAddNote = api(
  { method: "POST", path: "/admin/disputes/:dispute_id/notes", auth: true, expose: true },
  async (req: AdminAddNoteRequest): Promise<AdminAddNoteResponse> => {
    const auth = getAuthData()!;

    // Retrieve the role of the current user using tagged template literals
    const userRole = await db.queryRow<{ role: string }>`
      SELECT role
      FROM users
      WHERE id = ${auth.userID}
    `;

    if (userRole?.role !== "admin") {
      throw APIError.permissionDenied("Admin access required");
    }

    // Ensure the dispute exists
    const dispute = await db.queryRow<{ id: string }>`
      SELECT id
      FROM disputes
      WHERE id = ${req.dispute_id}
    `;

    if (!dispute) {
      throw APIError.notFound("Dispute not found");
    }

    // Insert the new note and return its ID.  Using a tagged template literal
    // automatically escapes and binds the values.
    const result = await db.queryRow<{ id: string }>`
      INSERT INTO dispute_notes (dispute_id, admin_id, note)
      VALUES (${req.dispute_id}, ${auth.userID}, ${req.note})
      RETURNING id
    `;

    return { note_id: result!.id };
  }
);
