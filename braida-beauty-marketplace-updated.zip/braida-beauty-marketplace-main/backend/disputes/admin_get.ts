import { api } from "encore.dev/api";
import { getAuthData } from "~encore/auth";
import db from "../db";
import { APIError } from "encore.dev/api";
import { DisputeBookingTimeline, DisputeWithDetails, DisputeAttachment, DisputeNote } from "./types";

export interface AdminGetDisputeRequest {
  dispute_id: string;
}

export interface AdminGetDisputeResponse {
  timeline: DisputeBookingTimeline;
  audit_logs: Array<{
    id: string;
    action: string;
    performed_by: string;
    performed_by_name: string;
    details: Record<string, any>;
    created_at: Date;
  }>;
}

export const adminGet = api(
  { method: "GET", path: "/admin/disputes/:dispute_id", auth: true, expose: true },
  async (req: AdminGetDisputeRequest): Promise<AdminGetDisputeResponse> => {
    const auth = getAuthData()!;

    // Fetch the current user's role using a tagged template literal. This
    // avoids positional parameters and improves safety.
    const userRole = await db.queryRow<{ role: string }>`
      SELECT role
      FROM users
      WHERE id = ${auth.userID}
    `;

    if (userRole?.role !== "admin") {
      throw APIError.permissionDenied("Admin access required");
    }

    const dispute = await db.queryRow<DisputeWithDetails>`
      SELECT 
        d.*,
        u.name AS raised_by_name,
        u.email AS raised_by_email,
        ra.name AS resolved_by_name
      FROM disputes d
      JOIN users u ON d.raised_by = u.id
      LEFT JOIN users ra ON d.resolved_by = ra.id
      WHERE d.id = ${req.dispute_id}
    `;

    if (!dispute) {
      throw APIError.notFound("Dispute not found");
    }

    const booking = await db.queryRow<{
      id: string;
      client_id: string;
      freelancer_id: string;
      service_id: string;
      scheduled_start: Date;
      scheduled_end: Date;
      status: string;
      payment_status?: string;
      total_amount: number;
    }>`
      SELECT 
        b.id,
        b.client_id,
        b.freelancer_id,
        b.service_id,
        b.scheduled_start,
        b.scheduled_end,
        b.status,
        b.payment_status,
        b.total_amount
      FROM bookings b
      WHERE b.id = ${dispute.booking_id}
    `;

    if (!booking) {
      throw APIError.notFound("Booking not found");
    }

    const client = await db.queryRow<{ name: string }>`
      SELECT name
      FROM users
      WHERE id = ${booking.client_id}
    `;

    const freelancer = await db.queryRow<{ name: string }>`
      SELECT name
      FROM users
      WHERE id = ${booking.freelancer_id}
    `;

    const service = await db.queryRow<{ name: string }>`
      SELECT name
      FROM services
      WHERE id = ${booking.service_id}
    `;

    // Pull attachments, notes and audit logs as arrays.  Using queryAll
    // removes the need for async iteration and provides a synchronous array
    // result that is easier to work with.
    const attachments = await db.queryAll<DisputeAttachment>`
      SELECT *
      FROM dispute_attachments
      WHERE dispute_id = ${req.dispute_id}
      ORDER BY uploaded_at DESC
    `;

    const notes = await db.queryAll<DisputeNote>`
      SELECT *
      FROM dispute_notes
      WHERE dispute_id = ${req.dispute_id}
      ORDER BY created_at ASC
    `;

    const auditLogRows = await db.queryAll<{
      id: string;
      action: string;
      performed_by: string;
      performed_by_name: string;
      details: Record<string, any>;
      created_at: Date;
    }>`
      SELECT 
        dal.id,
        dal.action,
        dal.performed_by,
        u.name AS performed_by_name,
        dal.details,
        dal.created_at
      FROM dispute_audit_logs dal
      LEFT JOIN users u ON dal.performed_by = u.id
      WHERE dal.dispute_id = ${req.dispute_id}
      ORDER BY dal.created_at DESC
    `;
    const auditLogs: Array<{
      id: string;
      action: string;
      performed_by: string;
      performed_by_name: string;
      details: Record<string, any>;
      created_at: Date;
    }> = auditLogRows;

    // Attach arrays to the dispute object
    dispute.attachments = attachments;
    dispute.notes = notes;

    const timeline: DisputeBookingTimeline = {
      booking_id: booking.id,
      client_name: client?.name || "Unknown",
      freelancer_name: freelancer?.name || "Unknown",
      service_name: service?.name || "Unknown",
      scheduled_start: booking.scheduled_start,
      scheduled_end: booking.scheduled_end,
      booking_status: booking.status,
      payment_status: booking.payment_status,
      total_amount: booking.total_amount,
      dispute,
    };

    return {
      timeline,
      audit_logs: auditLogs,
    };
  }
);
