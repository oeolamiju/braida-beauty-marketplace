import { api } from "encore.dev/api";
import { getAuthData } from "~encore/auth";
import db from "../db";
import { APIError } from "encore.dev/api";
import { DisputeWithDetails, DisputeAttachment, DisputeNote } from "./types";

export interface GetDisputeRequest {
  dispute_id: string;
}

export interface GetDisputeResponse {
  dispute: DisputeWithDetails;
}

export const get = api(
  { method: "GET", path: "/disputes/:dispute_id", auth: true, expose: true },
  async (req: GetDisputeRequest): Promise<GetDisputeResponse> => {
    const auth = getAuthData()!;

    // Retrieve the dispute details using tagged template literals. This
    // eliminates the need for positional parameters and leverages
    // db.queryRow to return a single result.
    const dispute = await db.queryRow<DisputeWithDetails>`
      SELECT 
        d.*,
        u.name AS raised_by_name,
        u.email AS raised_by_email,
        ra.name AS resolved_by_name
      FROM disputes d
      JOIN users u ON d.raised_by = u.id
      LEFT JOIN users ra ON d.resolved_by = ra.id
      WHERE d.id = ${req.dispute_id}
    `;

    if (!dispute) {
      throw APIError.notFound("Dispute not found");
    }

    const booking = await db.queryRow<{ client_id: string; freelancer_id: string }>`
      SELECT client_id, freelancer_id
      FROM bookings
      WHERE id = ${dispute.booking_id}
    `;

    const userRole = await db.queryRow<{ role: string }>`
      SELECT role
      FROM users
      WHERE id = ${auth.userID}
    `;

    if (
      userRole?.role !== "admin" &&
      auth.userID !== booking?.client_id &&
      auth.userID !== booking?.freelancer_id
    ) {
      throw APIError.permissionDenied("Access denied");
    }

    // Pull attachments and notes as arrays instead of using async iterators.
    const attachments = await db.queryAll<DisputeAttachment>`
      SELECT *
      FROM dispute_attachments
      WHERE dispute_id = ${req.dispute_id}
      ORDER BY uploaded_at DESC
    `;

    const notes = await db.queryAll<DisputeNote>`
      SELECT *
      FROM dispute_notes
      WHERE dispute_id = ${req.dispute_id}
      ORDER BY created_at ASC
    `;

    // Attach the related arrays to the dispute object.  This preserves
    // existing response shape while removing the need for manual iteration.
    dispute.attachments = attachments;
    dispute.notes = notes;

    return { dispute };
  }
);
