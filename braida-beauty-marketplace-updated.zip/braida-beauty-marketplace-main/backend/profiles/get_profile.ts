import { api, APIError } from "encore.dev/api";
import { getAuthData } from "~encore/auth";
import db from "../db";

export interface FreelancerProfile {
  userId: string;
  displayName: string;
  bio: string | null;
  profilePhotoUrl: string | null;
  locationArea: string;
  postcode: string;
  travelRadiusMiles: number;
  categories: string[];
  verificationStatus: string;
  avgRating: number | null;
  totalReviews: number;
  createdAt: Date;
}

export const getProfile = api(
  { method: "GET", path: "/profiles/:userId", expose: true, auth: false },
  async ({ userId }: { userId: string }): Promise<FreelancerProfile> => {
    const rows = await db.queryAll`
      SELECT 
        fp.user_id,
        fp.display_name,
        fp.bio,
        fp.profile_photo_url,
        fp.location_area,
        fp.postcode,
        fp.travel_radius_miles,
        fp.categories,
        fp.verification_status,
        fp.created_at,
        COALESCE(AVG(r.rating), NULL) as avg_rating,
        COUNT(r.id) as total_reviews
      FROM freelancer_profiles fp
      LEFT JOIN reviews r ON r.freelancer_id = fp.user_id
      WHERE fp.user_id = ${userId}
      GROUP BY fp.user_id, fp.display_name, fp.bio, fp.profile_photo_url, 
               fp.location_area, fp.postcode, fp.travel_radius_miles, 
               fp.categories, fp.verification_status, fp.created_at
    `;

    if (rows.length === 0) {
      throw APIError.notFound("Profile not found");
    }

    const row = rows[0];
    return {
      userId: row.user_id,
      displayName: row.display_name,
      bio: row.bio,
      profilePhotoUrl: row.profile_photo_url,
      locationArea: row.location_area,
      postcode: row.postcode,
      travelRadiusMiles: row.travel_radius_miles,
      categories: row.categories || [],
      verificationStatus: row.verification_status,
      avgRating: row.avg_rating ? parseFloat(row.avg_rating) : null,
      totalReviews: parseInt(row.total_reviews),
      createdAt: row.created_at,
    };
  }
);
