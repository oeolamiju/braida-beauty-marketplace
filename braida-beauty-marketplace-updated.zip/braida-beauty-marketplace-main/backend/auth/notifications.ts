import { secret } from "encore.dev/config";
import { sendEmail } from "../notifications/email_service";

const appUrl = secret("AppURL");

export async function sendVerificationEmail(email: string, token: string): Promise<void> {
  const verificationUrl = `${appUrl()}/auth/verify?token=${token}`;
  
  console.log(`[EMAIL] Sending verification email to ${email}`);
  
  await sendEmail({
    to: email,
    subject: "Verify Your Email - Braida",
    html: getVerificationEmailTemplate(verificationUrl),
  });
}

export async function sendVerificationSMS(phone: string, token: string): Promise<void> {
  console.log(`[SMS] Verification code for ${phone}: ${token}`);
}

export async function sendPasswordResetEmail(email: string, token: string): Promise<void> {
  const resetUrl = `${appUrl()}/auth/reset-password?token=${token}`;
  
  console.log(`[EMAIL] Sending password reset email to ${email}`);
  
  await sendEmail({
    to: email,
    subject: "Reset Your Password - Braida",
    html: getPasswordResetEmailTemplate(resetUrl),
  });
}

function getVerificationEmailTemplate(verificationUrl: string): string {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #f8f9fa; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
          .content { background: white; padding: 30px; border: 1px solid #e0e0e0; }
          .button { display: inline-block; padding: 12px 24px; background: #000; color: white; text-decoration: none; border-radius: 6px; margin: 20px 0; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Welcome to Braida! ✨</h1>
          </div>
          <div class="content">
            <p>Thank you for signing up!</p>
            <p>To complete your registration and start booking beauty services or offering your services, please verify your email address by clicking the button below:</p>
            <a href="${verificationUrl}" class="button">Verify Email Address</a>
            <p>Or copy and paste this link into your browser:</p>
            <p style="word-break: break-all; color: #666; font-size: 12px;">${verificationUrl}</p>
            <p>This verification link will expire in 24 hours.</p>
            <p>If you didn't create an account with Braida, you can safely ignore this email.</p>
          </div>
          <div class="footer">
            <p>© 2025 Braida. All rights reserved.</p>
          </div>
        </div>
      </body>
    </html>
  `;
}

function getPasswordResetEmailTemplate(resetUrl: string): string {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #fef3c7; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
          .content { background: white; padding: 30px; border: 1px solid #e0e0e0; }
          .button { display: inline-block; padding: 12px 24px; background: #000; color: white; text-decoration: none; border-radius: 6px; margin: 20px 0; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
          .warning { background: #fef3c7; padding: 15px; border-radius: 6px; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Reset Your Password 🔐</h1>
          </div>
          <div class="content">
            <p>We received a request to reset your password for your Braida account.</p>
            <p>Click the button below to create a new password:</p>
            <a href="${resetUrl}" class="button">Reset Password</a>
            <p>Or copy and paste this link into your browser:</p>
            <p style="word-break: break-all; color: #666; font-size: 12px;">${resetUrl}</p>
            <div class="warning">
              <p style="margin: 0;"><strong>⚠️ Important:</strong> This password reset link will expire in 24 hours for security purposes.</p>
            </div>
            <p>If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.</p>
          </div>
          <div class="footer">
            <p>© 2025 Braida. All rights reserved.</p>
          </div>
        </div>
      </body>
    </html>
  `;
}
