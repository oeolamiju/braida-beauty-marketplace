import { api, APIError, Cookie } from "encore.dev/api";
import bcrypt from "bcryptjs";
import db from "../db";
import { generateToken } from "./auth";
import { checkRateLimit } from "../shared/rate_limiter";

export interface LoginRequest {
  emailOrPhone: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  session: Cookie<"session">;
  user: {
    id: string;
    firstName: string;
    lastName: string;
    email: string | null;
    phone: string | null;
    role: string;
    isVerified: boolean;
  };
}

export const login = api<LoginRequest, LoginResponse>(
  { expose: true, method: "POST", path: "/auth/login" },
  async (req) => {
    await checkRateLimit(req.emailOrPhone, "auth_login");
    const user = await db.queryRow<{
      id: string;
      first_name: string;
      last_name: string;
      email: string | null;
      phone: string | null;
      password_hash: string | null;
      role: string;
      is_verified: boolean;
      status: string;
    }>`
      SELECT id, first_name, last_name, email, phone, password_hash, role, is_verified, status
      FROM users
      WHERE email = ${req.emailOrPhone} OR phone = ${req.emailOrPhone}
    `;

    if (!user || !user.password_hash) {
      throw APIError.unauthenticated("invalid credentials");
    }

    const isValidPassword = await bcrypt.compare(req.password, user.password_hash);
    if (!isValidPassword) {
      throw APIError.unauthenticated("invalid credentials");
    }

    if (user.status === "suspended") {
      throw APIError.permissionDenied("account suspended. Please contact support.");
    }

    const token = generateToken({
      userId: user.id,
      email: user.email || user.phone || "",
      role: user.role,
      isVerified: user.is_verified,
    });

    return {
      token,
      session: {
        value: token,
        expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        httpOnly: true,
        secure: true,
        sameSite: "Lax",
      },
      user: {
        id: user.id,
        firstName: user.first_name,
        lastName: user.last_name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isVerified: user.is_verified,
      },
    };
  }
);
