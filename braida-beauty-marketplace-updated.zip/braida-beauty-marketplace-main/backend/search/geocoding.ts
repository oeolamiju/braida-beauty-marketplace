const POSTCODE_AREAS: Record<string, { lat: number; lng: number }> = {
  "SW": { lat: 51.4975, lng: -0.1357 },
  "SE": { lat: 51.4549, lng: -0.0733 },
  "E": { lat: 51.5406, lng: -0.0538 },
  "W": { lat: 51.5101, lng: -0.1929 },
  "N": { lat: 51.5656, lng: -0.1060 },
  "NW": { lat: 51.5434, lng: -0.2052 },
  "EC": { lat: 51.5200, lng: -0.0966 },
  "WC": { lat: 51.5152, lng: -0.1231 },
  "B": { lat: 52.4862, lng: -1.8904 },
  "M": { lat: 53.4808, lng: -2.2426 },
  "L": { lat: 53.4084, lng: -2.9916 },
  "LS": { lat: 53.8008, lng: -1.5491 },
  "NG": { lat: 52.9548, lng: -1.1581 },
  "S": { lat: 53.3811, lng: -1.4701 },
  "BS": { lat: 51.4545, lng: -2.5879 },
  "GL": { lat: 51.8642, lng: -2.2381 },
  "OX": { lat: 51.7520, lng: -1.2577 },
  "CB": { lat: 52.2053, lng: 0.1218 },
  "BR": { lat: 51.4000, lng: 0.0150 },
  "CR": { lat: 51.3762, lng: -0.0982 },
  "KT": { lat: 51.3644, lng: -0.2787 },
  "SM": { lat: 51.3798, lng: -0.1789 },
  "TW": { lat: 51.4465, lng: -0.3360 },
  "UB": { lat: 51.5352, lng: -0.4780 },
};

const CITY_COORDINATES: Record<string, { lat: number; lng: number }> = {
  "LONDON": { lat: 51.5074, lng: -0.1278 },
  "BIRMINGHAM": { lat: 52.4862, lng: -1.8904 },
  "MANCHESTER": { lat: 53.4808, lng: -2.2426 },
  "LIVERPOOL": { lat: 53.4084, lng: -2.9916 },
  "LEEDS": { lat: 53.8008, lng: -1.5491 },
  "SHEFFIELD": { lat: 53.3811, lng: -1.4701 },
  "BRISTOL": { lat: 51.4545, lng: -2.5879 },
  "NOTTINGHAM": { lat: 52.9548, lng: -1.1581 },
  "GLASGOW": { lat: 55.8642, lng: -4.2518 },
  "EDINBURGH": { lat: 55.9533, lng: -3.1883 },
  "OXFORD": { lat: 51.7520, lng: -1.2577 },
  "CAMBRIDGE": { lat: 52.2053, lng: 0.1218 },
  "PECKHAM": { lat: 51.4741, lng: -0.0691 },
  "SHOREDITCH": { lat: 51.5242, lng: -0.0778 },
  "CAMDEN": { lat: 51.5390, lng: -0.1426 },
  "BRIXTON": { lat: 51.4613, lng: -0.1157 },
  "HACKNEY": { lat: 51.5450, lng: -0.0553 },
  "ISLINGTON": { lat: 51.5465, lng: -0.1058 },
  "CROYDON": { lat: 51.3762, lng: -0.0982 },
  "Kingston": { lat: 51.4123, lng: -0.3007 },
  "GREENWICH": { lat: 51.4826, lng: 0.0077 },
  "LEWISHAM": { lat: 51.4415, lng: -0.0117 },
};

function extractPostcodeArea(postcode: string): string {
  const normalized = postcode.toUpperCase().replace(/\s/g, '');
  const match = normalized.match(/^([A-Z]{1,2})/);
  return match ? match[1] : '';
}

export function getPostcodeCoordinates(postcode: string): { lat: number; lng: number } | null {
  if (!postcode || postcode.trim() === '') {
    return null;
  }

  const normalized = postcode.toUpperCase().trim();
  
  const cityCoords = CITY_COORDINATES[normalized];
  if (cityCoords) {
    return cityCoords;
  }
  
  for (const [city, coords] of Object.entries(CITY_COORDINATES)) {
    if (normalized.includes(city) || city.includes(normalized)) {
      return coords;
    }
  }
  
  const area = extractPostcodeArea(postcode);
  return POSTCODE_AREAS[area] || null;
}

export function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 3959;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
