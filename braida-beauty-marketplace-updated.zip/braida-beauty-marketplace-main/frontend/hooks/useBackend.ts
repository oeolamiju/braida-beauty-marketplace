import backend from "@/lib/backend";

export function useBackend() {
  return backend;
}
