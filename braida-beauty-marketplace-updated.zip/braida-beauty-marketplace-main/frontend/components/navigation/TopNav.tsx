import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, User, LogOut, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { NotificationBell } from "@/components/NotificationBell";
import GlobalSearch from "@/components/GlobalSearch";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useEffect, useState } from "react";

interface TopNavProps {
  role?: "client" | "freelancer" | "admin";
}

export default function TopNav({ role }: TopNavProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    if (role) {
      const userStr = localStorage.getItem("user");
      if (userStr) {
        setUser(JSON.parse(userStr));
      }
    }
  }, [role]);

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("user");
    navigate("/");
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/98 backdrop-blur-md border-b border-gray-200 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <Link to={role ? `/${role}` : "/"} className="flex items-center space-x-3 group">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-600 to-amber-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow">
              <span className="text-white font-bold text-xl">B</span>
            </div>
            <span className="font-bold text-2xl bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Braida</span>
          </Link>

          <div className="flex-1 flex items-center justify-center">
            <div className="hidden md:flex items-center space-x-6">
              {!role && (
                <>
                  <Link 
                    to="/discover" 
                    className={`font-medium transition-colors ${
                      isActive('/discover') ? 'text-orange-600' : 'text-gray-700 hover:text-orange-600'
                    }`}
                  >
                    Find Talent
                  </Link>
                  <Link 
                    to="/auth/register" 
                    className={`font-medium transition-colors ${
                      isActive('/auth/register') ? 'text-orange-600' : 'text-gray-700 hover:text-orange-600'
                    }`}
                  >
                    Offer Service
                  </Link>
                  <Link 
                    to="/styles" 
                    className={`font-medium transition-colors ${
                      isActive('/styles') ? 'text-orange-600' : 'text-gray-700 hover:text-orange-600'
                    }`}
                  >
                    Styles
                  </Link>
                </>
              )}
              {role === 'client' && (
                <>
                  <Link 
                    to="/client/discover" 
                    className={`font-medium transition-colors ${
                      isActive('/client/discover') ? 'text-orange-600' : 'text-gray-700 hover:text-orange-600'
                    }`}
                  >
                    Home
                  </Link>
                  <Link 
                    to="/client/styles" 
                    className={`font-medium transition-colors ${
                      isActive('/client/styles') ? 'text-orange-600' : 'text-gray-700 hover:text-orange-600'
                    }`}
                  >
                    Styles
                  </Link>
                  <Link 
                    to="/client/bookings" 
                    className={`font-medium transition-colors ${
                      isActive('/client/bookings') ? 'text-orange-600' : 'text-gray-700 hover:text-orange-600'
                    }`}
                  >
                    Bookings
                  </Link>
                </>
              )}
              {role === 'freelancer' && (
                <>
                  <Link 
                    to="/freelancer/dashboard" 
                    className={`font-medium transition-colors ${
                      isActive('/freelancer/dashboard') ? 'text-orange-600' : 'text-gray-700 hover:text-orange-600'
                    }`}
                  >
                    Home
                  </Link>
                  <Link 
                    to="/freelancer/bookings" 
                    className={`font-medium transition-colors ${
                      isActive('/freelancer/bookings') ? 'text-orange-600' : 'text-gray-700 hover:text-orange-600'
                    }`}
                  >
                    Bookings
                  </Link>
                  <Link 
                    to="/freelancer/services" 
                    className={`font-medium transition-colors ${
                      isActive('/freelancer/services') ? 'text-orange-600' : 'text-gray-700 hover:text-orange-600'
                    }`}
                  >
                    Services
                  </Link>
                </>
              )}
              {role === 'admin' && (
                <>
                  <Link 
                    to="/admin/dashboard" 
                    className={`font-medium transition-colors ${
                      isActive('/admin/dashboard') ? 'text-orange-600' : 'text-gray-700 hover:text-orange-600'
                    }`}
                  >
                    Home
                  </Link>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <GlobalSearch role={role} />
            {!role && (
              <>
                <Button variant="ghost" size="sm" asChild className="hidden md:inline-flex font-medium">
                  <Link to="/auth/login">Log In</Link>
                </Button>
                <Button size="sm" asChild className="hidden md:inline-flex bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 font-medium px-6">
                  <Link to="/auth/register">Sign Up</Link>
                </Button>
              </>
            )}
            {role && (
              <>
                <NotificationBell />
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="rounded-full hover:bg-orange-100">
                      {user?.profilePhoto ? (
                        <img src={user.profilePhoto} alt="Profile" className="h-8 w-8 rounded-full object-cover" />
                      ) : (
                        <User className="h-5 w-5" />
                      )}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <div className="px-2 py-1.5">
                      <p className="text-sm font-medium">{user?.displayName || user?.email}</p>
                      <p className="text-xs text-muted-foreground capitalize">{user?.role?.toLowerCase()}</p>
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate(`/${role}/profile`)}>
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate(`/${role}/notifications`)}>
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="text-red-600 focus:text-red-600">
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Log Out</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            )}
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
