import ServiceForm from "@/components/ServiceForm";

export default function ServiceNew() {
  return <ServiceForm mode="create" />;
}
