import { useState, useEffect } from "react";
import { useBackend } from "@/hooks/useBackend";
import { useApiError } from "@/hooks/useApiError";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import AvailabilityCalendar from "@/components/AvailabilityCalendar";
import { Calendar, Clock, Plus, Trash2, Save } from "lucide-react";

interface AvailabilityRule {
  dayOfWeek: number;
  startTime: string;
  endTime: string;
}

interface AvailabilityException {
  id: number;
  startDatetime: string;
  endDatetime: string;
  type: 'blocked' | 'extra';
}

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function Availability() {
  const backend = useBackend();
  const { showError } = useApiError();
  const { toast } = useToast();

  const [minLeadTimeHours, setMinLeadTimeHours] = useState(0);
  const [maxBookingsPerDay, setMaxBookingsPerDay] = useState<number | null>(null);
  const [rules, setRules] = useState<Record<number, { startTime: string; endTime: string }>>({});
  const [exceptions, setExceptions] = useState<AvailabilityException[]>([]);
  const [loading, setLoading] = useState(true);

  const [newExceptionStart, setNewExceptionStart] = useState("");
  const [newExceptionEnd, setNewExceptionEnd] = useState("");
  const [newExceptionType, setNewExceptionType] = useState<'blocked' | 'extra'>('blocked');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [settingsRes, rulesRes, exceptionsRes] = await Promise.all([
        backend.availability.getSettings(),
        backend.availability.getRules(),
        backend.availability.listExceptions({}),
      ]);

      setMinLeadTimeHours(settingsRes.settings.minLeadTimeHours);
      setMaxBookingsPerDay(settingsRes.settings.maxBookingsPerDay);

      const rulesMap: Record<number, { startTime: string; endTime: string }> = {};
      rulesRes.rules.forEach((rule) => {
        rulesMap[rule.dayOfWeek] = {
          startTime: rule.startTime.substring(0, 5),
          endTime: rule.endTime.substring(0, 5),
        };
      });
      setRules(rulesMap);
      setExceptions(exceptionsRes.exceptions);
    } catch (error) {
      showError(error);
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    try {
      await backend.availability.setSettings({
        minLeadTimeHours,
        maxBookingsPerDay: maxBookingsPerDay || undefined,
      });

      const ruleArray = Object.entries(rules).map(([day, times]) => ({
        dayOfWeek: parseInt(day),
        startTime: times.startTime,
        endTime: times.endTime,
      }));

      await backend.availability.setRules({ rules: ruleArray });

      toast({ title: "Availability settings saved" });
    } catch (error) {
      showError(error);
      console.error(error);
    }
  };

  const toggleDay = (dayOfWeek: number) => {
    setRules((prev) => {
      const newRules = { ...prev };
      if (newRules[dayOfWeek]) {
        delete newRules[dayOfWeek];
      } else {
        newRules[dayOfWeek] = { startTime: "09:00", endTime: "17:00" };
      }
      return newRules;
    });
  };

  const updateDayTime = (dayOfWeek: number, field: 'startTime' | 'endTime', value: string) => {
    setRules((prev) => ({
      ...prev,
      [dayOfWeek]: {
        ...prev[dayOfWeek],
        [field]: value,
      },
    }));
  };

  const addException = async () => {
    if (!newExceptionStart || !newExceptionEnd) {
      toast({ title: "Please fill in both start and end times", variant: "destructive" });
      return;
    }

    try {
      await backend.availability.addException({
        startDatetime: newExceptionStart,
        endDatetime: newExceptionEnd,
        type: newExceptionType,
      });

      setNewExceptionStart("");
      setNewExceptionEnd("");
      toast({ title: "Exception added" });
      loadData();
    } catch (error) {
      showError(error);
      console.error(error);
    }
  };

  const deleteException = async (id: number) => {
    try {
      await backend.availability.deleteException({ id });
      toast({ title: "Exception deleted" });
      loadData();
    } catch (error) {
      showError(error);
      console.error(error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-muted-foreground">Loading availability settings...</div>
      </div>
    );
  }

  return (
    <div className="container max-w-4xl py-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Availability Management</h1>
        <p className="text-muted-foreground">Set your working hours and manage exceptions</p>
      </div>

      <Card className="p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5" />
          <h2 className="text-xl font-semibold">General Settings</h2>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="text-sm font-medium">Minimum Lead Time</label>
            <select
              className="w-full mt-1 px-3 py-2 border rounded-md bg-background"
              value={minLeadTimeHours}
              onChange={(e) => setMinLeadTimeHours(parseInt(e.target.value))}
            >
              <option value="0">None (same-day allowed)</option>
              <option value="24">24 hours</option>
              <option value="48">48 hours</option>
              <option value="72">3 days</option>
              <option value="168">1 week</option>
            </select>
          </div>

          <div>
            <label className="text-sm font-medium">Max Bookings Per Day</label>
            <Input
              type="number"
              min="1"
              placeholder="Unlimited"
              className="mt-1"
              value={maxBookingsPerDay || ""}
              onChange={(e) => setMaxBookingsPerDay(e.target.value ? parseInt(e.target.value) : null)}
            />
          </div>
        </div>
      </Card>

      <Card className="p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          <h2 className="text-xl font-semibold">Working Days & Hours</h2>
        </div>

        <div className="space-y-2">
          {DAYS.map((day, index) => (
            <div key={index} className="flex items-center gap-4 p-3 border rounded-md">
              <input
                type="checkbox"
                className="w-4 h-4"
                checked={!!rules[index]}
                onChange={() => toggleDay(index)}
              />
              <span className="w-24 font-medium">{day}</span>
              {rules[index] && (
                <div className="flex gap-2 items-center flex-1">
                  <Input
                    type="time"
                    className="w-32"
                    value={rules[index].startTime}
                    onChange={(e) => updateDayTime(index, 'startTime', e.target.value)}
                  />
                  <span className="text-muted-foreground">to</span>
                  <Input
                    type="time"
                    className="w-32"
                    value={rules[index].endTime}
                    onChange={(e) => updateDayTime(index, 'endTime', e.target.value)}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="flex justify-end">
          <Button onClick={saveSettings}>
            <Save className="w-4 h-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </Card>

      <Card className="p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Plus className="w-5 h-5" />
          <h2 className="text-xl font-semibold">Exceptions</h2>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <div>
            <label className="text-sm font-medium">Start Date/Time</label>
            <Input
              type="datetime-local"
              className="mt-1"
              value={newExceptionStart}
              onChange={(e) => setNewExceptionStart(e.target.value)}
            />
          </div>
          <div>
            <label className="text-sm font-medium">End Date/Time</label>
            <Input
              type="datetime-local"
              className="mt-1"
              value={newExceptionEnd}
              onChange={(e) => setNewExceptionEnd(e.target.value)}
            />
          </div>
          <div>
            <label className="text-sm font-medium">Type</label>
            <select
              className="w-full mt-1 px-3 py-2 border rounded-md bg-background"
              value={newExceptionType}
              onChange={(e) => setNewExceptionType(e.target.value as 'blocked' | 'extra')}
            >
              <option value="blocked">Blocked (Unavailable)</option>
              <option value="extra">Extra (Override)</option>
            </select>
          </div>
        </div>

        <Button onClick={addException}>
          <Plus className="w-4 h-4 mr-2" />
          Add Exception
        </Button>

        {exceptions.length > 0 && (
          <div className="space-y-2">
            {exceptions.map((exception) => (
              <div key={exception.id} className="flex items-center justify-between p-3 border rounded-md">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <Badge variant={exception.type === 'blocked' ? 'destructive' : 'default'}>
                      {exception.type}
                    </Badge>
                    <span className="text-sm">
                      {new Date(exception.startDatetime).toLocaleString()} - {new Date(exception.endDatetime).toLocaleString()}
                    </span>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteException(exception.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </Card>

      <div>
        <h2 className="text-2xl font-bold mb-4">Calendar View</h2>
        <AvailabilityCalendar />
      </div>
    </div>
  );
}
