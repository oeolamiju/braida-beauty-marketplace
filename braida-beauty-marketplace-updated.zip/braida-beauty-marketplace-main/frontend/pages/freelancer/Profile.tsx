import { useState, useEffect } from "react";
import { User, MapPin, Camera, Loader2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import backend from "~backend/client";
import type { FreelancerProfile } from "~backend/profiles/get_profile";
import type { PortfolioItem } from "~backend/profiles/list_portfolio";
import { ImageUploader } from "@/components/ImageUploader";
import { PortfolioGallery } from "@/components/PortfolioGallery";
const TRAVEL_RADIUS_OPTIONS = [5, 10, 20];
const CATEGORY_OPTIONS = [
  { value: "hair", label: "Hair" },
  { value: "makeup", label: "Makeup" },
  { value: "gele", label: "Gele" },
  { value: "tailoring", label: "Tailoring" },
];

export default function FreelancerProfile() {
  const [profile, setProfile] = useState<FreelancerProfile | null>(null);
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    displayName: "",
    bio: "",
    profilePhotoUrl: "",
    locationArea: "",
    postcode: "",
    travelRadiusMiles: 5,
    categories: [] as string[],
  });

  const [portfolioCaption, setPortfolioCaption] = useState("");

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      setLoading(true);
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      const [profileData, portfolioData] = await Promise.all([
        backend.profiles.getProfile({ userId: user.id }),
        backend.profiles.listPortfolio({ userId: user.id }),
      ]);

      setProfile(profileData);
      setPortfolio(portfolioData.items);
      setFormData({
        displayName: profileData.displayName,
        bio: profileData.bio || "",
        profilePhotoUrl: profileData.profilePhotoUrl || "",
        locationArea: profileData.locationArea,
        postcode: profileData.postcode,
        travelRadiusMiles: profileData.travelRadiusMiles,
        categories: profileData.categories,
      });
    } catch (error) {
      console.error("Failed to load profile:", error);
      toast({
        title: "Error",
        description: "Failed to load profile",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    try {
      setSaving(true);
      await backend.profiles.updateProfile(formData);
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
      loadProfile();
    } catch (error) {
      console.error("Failed to save profile:", error);
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleProfilePhotoUpload = async (photoId: string) => {
    try {
      const photoUrl = `https://portfolio-images.s3.amazonaws.com/${photoId}`;
      await backend.profiles.updateProfile({
        profilePhotoUrl: photoUrl,
      });
      toast({
        title: "Success",
        description: "Profile photo updated",
      });
      loadProfile();
    } catch (error) {
      console.error("Failed to save profile photo:", error);
      toast({
        title: "Error",
        description: "Failed to update profile photo",
        variant: "destructive",
      });
    }
  };

  const handlePortfolioUpload = async (imageId: string) => {
    try {
      await backend.profiles.savePortfolioItem({
        imageId,
        caption: portfolioCaption || undefined,
      });
      setPortfolioCaption("");
      toast({
        title: "Success",
        description: "Portfolio image added",
      });
      loadProfile();
    } catch (error) {
      console.error("Failed to save portfolio item:", error);
      toast({
        title: "Error",
        description: "Failed to add portfolio image",
        variant: "destructive",
      });
    }
  };

  const handleDeletePortfolio = async (itemId: number) => {
    try {
      await backend.profiles.deletePortfolioItem({ itemId });
      toast({
        title: "Success",
        description: "Portfolio image deleted",
      });
      loadProfile();
    } catch (error) {
      console.error("Failed to delete portfolio item:", error);
      toast({
        title: "Error",
        description: "Failed to delete portfolio image",
        variant: "destructive",
      });
    }
  };

  const toggleCategory = (category: string) => {
    setFormData((prev) => ({
      ...prev,
      categories: prev.categories.includes(category)
        ? prev.categories.filter((c) => c !== category)
        : [...prev.categories, category],
    }));
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">My Profile</h1>
        <p className="text-muted-foreground">Manage your professional profile</p>
      </div>

      <div className="space-y-6">
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Basic Information</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Display Name
              </label>
              <Input
                value={formData.displayName}
                onChange={(e) =>
                  setFormData({ ...formData, displayName: e.target.value })
                }
                placeholder="Your professional name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Bio</label>
              <textarea
                className="w-full min-h-24 px-3 py-2 border border-border rounded-md bg-background text-foreground"
                value={formData.bio}
                onChange={(e) =>
                  setFormData({ ...formData, bio: e.target.value })
                }
                placeholder="Tell clients about yourself and your experience"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  <MapPin className="inline h-4 w-4 mr-1" />
                  Location Area/City
                </label>
                <Input
                  value={formData.locationArea}
                  onChange={(e) =>
                    setFormData({ ...formData, locationArea: e.target.value })
                  }
                  placeholder="e.g. Central London"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Postcode
                </label>
                <Input
                  value={formData.postcode}
                  onChange={(e) =>
                    setFormData({ ...formData, postcode: e.target.value })
                  }
                  placeholder="e.g. SW1A 1AA"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Travel Radius
              </label>
              <div className="flex gap-2">
                {TRAVEL_RADIUS_OPTIONS.map((radius) => (
                  <Button
                    key={radius}
                    variant={
                      formData.travelRadiusMiles === radius
                        ? "default"
                        : "outline"
                    }
                    onClick={() =>
                      setFormData({ ...formData, travelRadiusMiles: radius })
                    }
                  >
                    {radius} miles
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Categories Offered
              </label>
              <div className="flex flex-wrap gap-2">
                {CATEGORY_OPTIONS.map((cat) => (
                  <Badge
                    key={cat.value}
                    variant={
                      formData.categories.includes(cat.value)
                        ? "default"
                        : "outline"
                    }
                    className="cursor-pointer"
                    onClick={() => toggleCategory(cat.value)}
                  >
                    {cat.label}
                  </Badge>
                ))}
              </div>
            </div>

            <Button onClick={handleSaveProfile} disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Profile"
              )}
            </Button>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <Camera className="h-5 w-5 mr-2" />
            Portfolio
          </h2>

          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-medium mb-2">Add New Image</h3>
              <div className="space-y-3">
                <Input
                  value={portfolioCaption}
                  onChange={(e) => setPortfolioCaption(e.target.value)}
                  placeholder="Optional caption"
                />
                <ImageUploader
                  onUploadComplete={handlePortfolioUpload}
                  onError={(error) =>
                    toast({
                      title: "Upload Error",
                      description: error,
                      variant: "destructive",
                    })
                  }
                />
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium mb-3">Your Portfolio</h3>
              <PortfolioGallery
                items={portfolio}
                editable
                onDelete={handleDeletePortfolio}
              />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
