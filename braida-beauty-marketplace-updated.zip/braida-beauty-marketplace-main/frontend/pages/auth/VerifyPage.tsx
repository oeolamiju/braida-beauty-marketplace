import { useState, useEffect } from "react";
import { useNavigate, useSearchParams, useLocation } from "react-router-dom";
import backend from "~backend/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { CheckCircle2 } from "lucide-react";

export default function VerifyPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [verified, setVerified] = useState(false);
  const [token, setToken] = useState("");

  const emailOrPhone = location.state?.emailOrPhone || "";

  useEffect(() => {
    const tokenParam = searchParams.get("token");
    if (tokenParam) {
      setToken(tokenParam);
      handleVerify(tokenParam);
    }
  }, [searchParams]);

  const handleVerify = async (verificationToken?: string) => {
    const tokenToUse = verificationToken || token;
    if (!tokenToUse) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please enter verification token",
      });
      return;
    }

    setLoading(true);

    try {
      const response = await backend.auth.verify({ token: tokenToUse });

      localStorage.setItem("authToken", response.authToken);
      localStorage.setItem("user", JSON.stringify(response.user));

      setVerified(true);

      toast({
        title: "Success",
        description: response.message,
      });

      setTimeout(() => {
        if (response.user.role === "CLIENT") {
          navigate("/client/discover");
        } else if (response.user.role === "FREELANCER") {
          navigate("/freelancer/dashboard");
        }
      }, 2000);
    } catch (error: any) {
      console.error("Verification error:", error);
      toast({
        variant: "destructive",
        title: "Verification failed",
        description: error.message || "Invalid or expired verification token",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (!emailOrPhone) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Email or phone not found",
      });
      return;
    }

    setResendLoading(true);

    try {
      const response = await backend.auth.resendVerification({ emailOrPhone });

      toast({
        title: "Success",
        description: response.message,
      });
    } catch (error: any) {
      console.error("Resend error:", error);
      toast({
        variant: "destructive",
        title: "Resend failed",
        description: error.message || "Failed to resend verification",
      });
    } finally {
      setResendLoading(false);
    }
  };

  if (verified) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto" />
              <h2 className="text-2xl font-bold">Account Verified!</h2>
              <p className="text-muted-foreground">Redirecting you to your dashboard...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Verify Your Account</CardTitle>
          <CardDescription>
            Enter the verification code sent to {emailOrPhone || "your email or phone"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={(e) => { e.preventDefault(); handleVerify(); }} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Verification Token</label>
              <Input
                value={token}
                onChange={(e) => setToken(e.target.value)}
                placeholder="Enter verification token"
                required
              />
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Verifying..." : "Verify Account"}
            </Button>

            <div className="text-center text-sm">
              Didn't receive the code?{" "}
              <button
                type="button"
                onClick={handleResend}
                disabled={resendLoading || !emailOrPhone}
                className="text-primary hover:underline disabled:opacity-50"
              >
                {resendLoading ? "Sending..." : "Resend"}
              </button>
            </div>

            <div className="text-center text-sm">
              <a href="/auth/login" className="text-primary hover:underline">
                Back to login
              </a>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
