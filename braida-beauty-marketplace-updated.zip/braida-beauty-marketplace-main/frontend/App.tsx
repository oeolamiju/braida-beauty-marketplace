import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import { NotificationProvider } from "./contexts/NotificationContext";
import LandingPage from "./pages/LandingPage";
import TermsPage from "./pages/TermsPage";
import PrivacyPage from "./pages/PrivacyPage";
import RegisterPage from "./pages/auth/RegisterPage";
import LoginPage from "./pages/auth/LoginPage";
import VerifyPage from "./pages/auth/VerifyPage";
import ForgotPasswordPage from "./pages/auth/ForgotPasswordPage";
import ResetPasswordPage from "./pages/auth/ResetPasswordPage";
import ClientLayout from "./layouts/ClientLayout";
import FreelancerLayout from "./layouts/FreelancerLayout";
import AdminLayout from "./layouts/AdminLayout";
import ClientDiscover from "./pages/client/Discover";
import ClientBookings from "./pages/client/Bookings";
import ClientProfile from "./pages/client/Profile";
import FreelancerDashboard from "./pages/freelancer/Dashboard";
import FreelancerBookings from "./pages/freelancer/Bookings";
import FreelancerServices from "./pages/freelancer/Services";
import FreelancerProfile from "./pages/freelancer/Profile";
import ServiceNew from "./pages/freelancer/ServiceNew";
import ServiceEdit from "./pages/freelancer/ServiceEdit";
import ServiceDetail from "./pages/ServiceDetail";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminUsers from "./pages/admin/Users";
import AdminListings from "./pages/admin/Listings";
import AdminBookings from "./pages/admin/Bookings";
import AdminBookingDetail from "./pages/admin/BookingDetail";
import AdminSettings from "./pages/admin/Settings";
import AdminDisputes from "./pages/admin/Disputes";
import AdminDisputeDetail from "./pages/admin/DisputeDetail";
import AdminReports from "./pages/admin/Reports";
import AdminVerifications from "./pages/admin/Verifications";
import VerificationsList from "./pages/admin/VerificationsList";
import VerificationDetail from "./pages/admin/VerificationDetail";
import FreelancerVerification from "./pages/freelancer/Verification";
import FreelancerAvailability from "./pages/freelancer/Availability";
import FreelancerPublicProfile from "./pages/FreelancerPublicProfile";
import ClientStyles from "./pages/client/Styles";
import ClientStyleDetail from "./pages/client/StyleDetail";
import ClientBookingDetail from "./pages/client/BookingDetail";
import FreelancerBookingDetail from "./pages/freelancer/BookingDetail";
import AdminStyles from "./pages/admin/Styles";
import PublicDiscover from "./pages/public/Discover";
import PublicStyles from "./pages/public/Styles";
import PublicStyleDetail from "./pages/public/StyleDetail";
import NotificationSettings from "./pages/NotificationSettings";
import PolicySettings from "./pages/admin/PolicySettings";
import FreelancerEarnings from "./pages/freelancer/Earnings";
import FreelancerPayoutSetup from "./pages/freelancer/PayoutSetup";
import AdminPaymentSettings from "./pages/admin/PaymentSettings";
import AdminPayouts from "./pages/admin/Payouts";
import AdminPayoutDetail from "./pages/admin/PayoutDetail";
import AdminReviews from "./pages/admin/Reviews";
import KPIDashboard from "./pages/admin/KPIDashboard";

export default function App() {
  return (
    <NotificationProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />

          <Route path="/auth/register" element={<RegisterPage />} />
          <Route path="/auth/login" element={<LoginPage />} />
          <Route path="/auth/verify" element={<VerifyPage />} />
          <Route path="/auth/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/auth/reset-password" element={<ResetPasswordPage />} />

          <Route path="/discover" element={<PublicDiscover />} />
          <Route path="/styles" element={<PublicStyles />} />
          <Route path="/styles/:styleId" element={<PublicStyleDetail />} />
          <Route path="/freelancers/:userId" element={<FreelancerPublicProfile />} />
          <Route path="/services/:id" element={<ServiceDetail />} />

          <Route path="/client" element={<ClientLayout />}>
            <Route index element={<Navigate to="/client/discover" replace />} />
            <Route path="discover" element={<ClientDiscover />} />
            <Route path="bookings" element={<ClientBookings />} />
            <Route path="bookings/:id" element={<ClientBookingDetail />} />
            <Route path="profile" element={<ClientProfile />} />
            <Route path="styles" element={<ClientStyles />} />
            <Route path="styles/:styleId" element={<ClientStyleDetail />} />
            <Route path="services/:id" element={<ServiceDetail />} />
            <Route path="notifications" element={<NotificationSettings />} />
          </Route>

          <Route path="/freelancer" element={<FreelancerLayout />}>
            <Route index element={<Navigate to="/freelancer/dashboard" replace />} />
            <Route path="dashboard" element={<FreelancerDashboard />} />
            <Route path="bookings" element={<FreelancerBookings />} />
            <Route path="bookings/:id" element={<FreelancerBookingDetail />} />
            <Route path="services" element={<FreelancerServices />} />
            <Route path="services/new" element={<ServiceNew />} />
            <Route path="services/:id/edit" element={<ServiceEdit />} />
            <Route path="availability" element={<FreelancerAvailability />} />
            <Route path="profile" element={<FreelancerProfile />} />
            <Route path="verification" element={<FreelancerVerification />} />
            <Route path="earnings" element={<FreelancerEarnings />} />
            <Route path="payout-setup" element={<FreelancerPayoutSetup />} />
            <Route path="notifications" element={<NotificationSettings />} />
          </Route>

          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<Navigate to="/admin/dashboard" replace />} />
            <Route path="dashboard" element={<AdminDashboard />} />
            <Route path="kpis" element={<KPIDashboard />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="listings" element={<AdminListings />} />
            <Route path="bookings" element={<AdminBookings />} />
            <Route path="bookings/:bookingId" element={<AdminBookingDetail />} />
            <Route path="disputes" element={<AdminDisputes />} />
            <Route path="disputes/:id" element={<AdminDisputeDetail />} />
            <Route path="reports" element={<AdminReports />} />
            <Route path="reviews" element={<AdminReviews />} />
            <Route path="verifications" element={<VerificationsList />} />
            <Route path="verifications/:freelancerId" element={<VerificationDetail />} />
            <Route path="styles" element={<AdminStyles />} />
            <Route path="payouts" element={<AdminPayouts />} />
            <Route path="payouts/:id" element={<AdminPayoutDetail />} />
            <Route path="settings" element={<AdminSettings />} />
            <Route path="settings/policies" element={<PolicySettings />} />
            <Route path="settings/payments" element={<AdminPaymentSettings />} />
          </Route>
        </Routes>
      </BrowserRouter>
      <Toaster />
    </NotificationProvider>
  );
}
